export const AUTH_CONFIG = {
  domain: 'dev-ie1nel7a.auth0.com',
  clientId: 'FoCySY3EpIq1cYZfX67Uvb0Rb5kIka8P',
  callbackUrl: 'http://localhost:3000/callback'
}
